#ifndef __COOL_LIST_H__
#define __COOL_LIST_H__

#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include "segel.h"
#include "structs.h"

Node* node_constructor(int file_descriptor, Time arrival);
void  node_destructor(Node* node);
List* list_constructor(int size);
int   list_get_size(List* list);
int   list_is_full(List* list);
int   list_is_empty(List* list);
void  list_insert(List* list, int file_descriptor, Time arrival);
Node* list_remove(List* list);
Node* list_remove_index(List* list, int index);
Node* list_remove_random(List* list);

#endif /* __COOL_LIST_H__ */