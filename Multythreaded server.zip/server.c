#include <pthread.h>
#include <sys/time.h>
#include "segel.h"
#include "request.h"

// OUR HEADERS:
#include "list.h"
#include "structs.h"

// GLOBAL VARIABLES:
Policy    policy;
int       thread_count;
int       queue_size;
int       active_requests;
List*     wait_list;
Condition master_condition;
Condition thread_condition;
Mutex     lock;

// AUXILIARY FUNCTION DECLARATIONS:
void  get_arguments(int argc, char *argv[], int *port, int* thread_count, int* queue_size, Policy* policy);
void* thread_routine(void *args);
int   server_is_overloaded();
Time  get_time();

int main(int argc, char *argv[])
{
    int listenfd, connfd, port, clientlen;
    struct sockaddr_in clientaddr;
    
    // OUR VARIABLES:
    pthread_t* thread_array;
    Time arrival;
    
    // INITIALIZE VARIABLES:
    get_arguments(argc, argv, &port, &thread_count, &queue_size, &policy);
    active_requests = 0;
    wait_list = list_constructor(queue_size);
    thread_array = malloc(sizeof(pthread_t) * thread_count);
    InitializeCondition(&master_condition);
    InitializeCondition(&thread_condition);
    InitializeLock(&lock);

    // CREATE THREADS:
    for (int i = 0; i < thread_count; i++)
    {
        int* id = malloc(sizeof(*id));
        *id = i;
        pthread_create(&thread_array[i], NULL, thread_routine, (void*)id);
    }

    // MAIN THREAD WAITS FOR REQUESTS:
    listenfd = Open_listenfd(port);
    while (1)
    {
        clientlen = sizeof(clientaddr);
        connfd = Accept(listenfd, (SA *)&clientaddr, (socklen_t *) &clientlen);
        arrival = get_time();

        Lock(&lock);
        if (server_is_overloaded())
        {
            switch (policy)
            {
                case BLOCK:
                {
                    while(server_is_overloaded())
                        ConditionWait(&master_condition, &lock);
                    break;
                }
                case DROP_TAIL:
                {
                    Close(connfd);
                    Unlock(&lock);
                    continue;
                }
                case DROP_HEAD:
                {
                    if (list_is_empty(wait_list))
                    {
                        Close(connfd);
                        Unlock(&lock);
                        continue;
                    }
                    else
                    {
                        Node* request;
                        request = list_remove(wait_list);
                        Close(request->file_descriptor);
                        node_destructor(request);
                    }
                    break;
                }
                case BLOCK_FLUSH:
                {
                    while(list_get_size(wait_list) || active_requests)
                        ConditionWait(&master_condition, &lock);
                    Close(connfd);
                    Unlock(&lock);
                    continue;
                }
                case DROP_RANDOM:
                {
                    int size;
                    int half;
                    Node* request;

                    size = list_get_size(wait_list);
                    half = 0.5 * size;
                    if (size % 2) half++;
                    
                    for (int i = 0; i < half; i++)
                    {
                        request = list_remove_random(wait_list);
                        Close(request->file_descriptor);
                        node_destructor(request);
                    }
                }
                default:
                    break;
            }
        }                 

        list_insert(wait_list, connfd, arrival);
        ConditionSignal(&thread_condition);
        Unlock(&lock);
    }
}

// AUXILIARY FUNCTION:

void* thread_routine(void* args)
{
    int file_descriptor;
    Node* request;
    Time current;
    Stats* stats;
    
    stats = calloc(1, sizeof(*stats));
    stats->id = *(int*)args;
    
    while(1)
    {
        Lock(&lock);
        while(list_is_empty(wait_list))
            ConditionWait(&thread_condition, &lock);
        
        request = list_remove(wait_list); 
        file_descriptor = request->file_descriptor;
        stats->arrival = request->arrival;
        node_destructor(request);
        active_requests++;
        Unlock(&lock);

        current = get_time();
        timersub(&current, &stats->arrival, &stats->dispatch);

        requestHandle(file_descriptor, stats);
        Close(file_descriptor);

        Lock(&lock);
        active_requests--;
        ConditionSignal(&master_condition);
        Unlock(&lock);
    }

    return NULL;
}

void get_arguments(int argc, char *argv[], int* port, int* thread_count, int* queue_size, Policy* policy)
{
    if (argc < 5)
    {
        printf("I NEED more pARraMetErs!\n");
        exit(1);
    }
    
    *port           = atoi(argv[1]);
    *thread_count   = atoi(argv[2]);
    *queue_size     = atoi(argv[3]);
    if      (strcmp(argv[4], "block") == 0)
                  *policy = BLOCK;
    else if (strcmp(argv[4], "dt") == 0)
                  *policy = DROP_TAIL;
    else if (strcmp(argv[4], "dh") == 0)
                  *policy = DROP_HEAD;
    else if (strcmp(argv[4], "bf") == 0)
                  *policy = BLOCK_FLUSH;
    else if (strcmp(argv[4], "random") == 0)
                  *policy = DROP_RANDOM;
    else // default
                  *policy = BLOCK;
}

int server_is_overloaded()
{ return (list_get_size(wait_list) + active_requests == queue_size); }

Time get_time()
{
    Time time;
    gettimeofday(&time,NULL);
    return time;
}