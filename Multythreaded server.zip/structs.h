#ifndef __COOL_STRUCTS_H__
#define __COOL_STRUCTS_H__

#include <sys/time.h>
#include <pthread.h>

typedef struct timeval  Time;
typedef pthread_mutex_t Mutex;
typedef pthread_cond_t  Condition;
typedef pthread_t       Thread;

typedef struct node
{
    int file_descriptor;
    Time arrival;
    struct node* next;
} Node;

typedef struct
{
    int max_size;
    int current_size;
    Node* head;
    Node* tail;
} List;

typedef enum
{
    BLOCK,
    DROP_TAIL,
    DROP_HEAD,
    BLOCK_FLUSH,
    DROP_RANDOM
} Policy;

typedef struct
{ 
    int id;
} Input;

typedef struct
{
	int id;
	int static_requests;
	int dynamic_requests;
	int total_requests;
    Time arrival;
    Time dispatch;
} Stats;

#endif /* __COOL_STRUCTS_H__ */