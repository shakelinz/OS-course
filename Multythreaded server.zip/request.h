#ifndef __REQUEST_H__
#define __REQUEST_H__

// OUR HEADERS:
#include "structs.h"

void requestHandle(int fd, /*OUR STUFF:*/ Stats* stats);

#endif
