#include "list.h"

Node* node_constructor(int file_descriptor, Time arrival)
{
    Node* node = (Node*)malloc(sizeof(*node));
    node->file_descriptor = file_descriptor;
    node->arrival = arrival;
    node->next = NULL;
    return node;
}

void node_destructor(Node* node)
{ free(node); }

List* list_constructor(int size)
{
    List* list = (List*)malloc(sizeof(*list));
    list->head = NULL;
    list->tail = NULL;
    list->current_size = 0;
    list->max_size = size;
    return list;
}

int list_get_size(List* list)
{ return list->current_size; }

int list_is_full(List* list)
{ return (list->current_size == list->max_size); }

int list_is_empty(List* list)
{ return (list->current_size == 0); }

void list_insert(List* list, int file_descriptor, Time arrival)
{
    if(list_is_full(list))
        return;

    Node* new_node = node_constructor(file_descriptor, arrival);
    if(list_is_empty(list))
    {
        list->head = new_node;
        list->tail = new_node;
    }
    else
    {
        list->tail->next = new_node;
        list->tail = new_node;
    }
    list->current_size++;
}

Node* list_remove(List* list)
{
    if(list_is_empty(list))
        return NULL;
    Node* node = list->head;
    list->head = node->next;
    if(node->next == NULL)
        list->tail = NULL;
    list->current_size--;
    return node;
}

Node* list_remove_index(List* list, int index)
{
    Node* node;
    Node* previous;

    if (list_is_empty(list)) return NULL;
    node = list->head;
    
    list->current_size--;
    
    if (index == 0)
    {
        list->head = node->next;
        if (list->head == NULL)
            list->tail = NULL;
        return node;
    }

    for (int i = 0; i < index; i++)
    {
        previous = node;
        node = node->next;
    }

    previous->next = node->next;

    if (previous->next == NULL)
        list->tail = previous;

    return node;
}

Node* list_remove_random(List* list)
{
    Node* node;
    Node* previous;
    int   index;

    if (list_is_empty(list)) return NULL;
    
    index = rand() % list->current_size;
    list->current_size--;
    node = list->head;
    
    if (index == 0)
    {
        list->head = node->next;
        if (list->head == NULL)
            list->tail = NULL;
        return node;
    }

    for (int i = 0; i < index; i++)
    {
        previous = node;
        node = node->next;
    }

    previous->next = node->next;

    if (previous->next == NULL)
        list->tail = previous;

    return node;
}
