// Includes:
#include <unistd.h>     // sbrk(), size_t
#include <cstring>      // memmove(), memset()
#include <sys/mman.h>   // mmap(), munmap()
#include <cmath>        // log2()

enum Return {SUCCESS, FAILURE};

// Constants:
const void*	    BAD_POINTER		= (void*)(-1);
const size_t	MAX_SIZE		= 1E8;
const size_t	MIN_BLOCK_SIZE	= 128;
const size_t	BIG_BLOCK_SIZE	= MIN_BLOCK_SIZE * 1024;
const int	    BIG_BLOCK_NUM	= 32;
const size_t	HEAP_SIZE		= BIG_BLOCK_NUM * BIG_BLOCK_SIZE;
const int	    MAX_ORDER		= 10;

struct Node
{
	int		order;
	size_t	size;
	bool	is_free;
	Node*	next;
	Node*	previous;

	void set(int order, size_t size, bool is_free, Node* next, Node* previous)
	{
		this->order     = order;
		this->size      = size;
		this->is_free   = is_free;
		this->next      = next;
		this->previous  = previous;
	}
}; // Node struct

bool pointer_comparison(Node*a,Node*b){return(intptr_t)a>(intptr_t)b;}

class List
{
  public:

	Node*   head;
	int     order;

	List() { head = nullptr; }

	bool is_empty() { return head == nullptr; }

	void insert(Node* node)
	{
		if (is_empty())
		{
			head = node;
			node->set(order, 0, true, nullptr, nullptr);
			return;
		}

		Node* iterator = head;
		Node* previous = iterator;

		while (iterator != nullptr)
		{
			if (pointer_comparison(iterator, node))
			{
				iterator->previous = node;
				break;
			}

			previous = iterator;
			iterator = iterator->next;
		}

		if (iterator == head)
		{
			head = node;
			previous = nullptr;
		}

		node->set(order, 0, true, iterator, previous);
	}

	void remove(Node* node)
	{
		if (node->next != nullptr)
			node->next->previous = node->previous;

		if (node->previous != nullptr)
			node->previous->next = node->next;
		else
			head = node->next;

		node->is_free = false;
	}

}; // List class

class Heap
{
  private:
  public:

	List	list[MAX_ORDER + 1];
	bool	initialized;
	size_t	allocated_blocks,	free_blocks,
			allocated_bytes,	free_bytes,
			metadata_size;

	// Helper functions:
	size_t order_to_size(int n){return MIN_BLOCK_SIZE*(1<<n);} // = 128 * 2^n
	int	size_to_order(size_t s){return ceil(log2(ceil((float)s/MIN_BLOCK_SIZE)));} // = smallest n such that: 128 * 2^n >= size
	Node*Map(size_t s){return(Node*)mmap(nullptr,s,PROT_READ|PROT_WRITE,MAP_ANON|MAP_PRIVATE,-1,0);}
	int	Unmap(Node*p,size_t s){return munmap((void*)p,s);}
	Node*pointer_addition(void*p,intptr_t a){return(Node*)((intptr_t)p+a);}
	Node*pointer_addition(Node*p,intptr_t a){return(Node*)((intptr_t)p+a);}
	Node*Sbrk(intptr_t s){return(Node*)sbrk(s);}
	Node*get_node(void*p){return(Node*)p-1;}
	void*get_pointer(Node*p){return(void*)(++p);}
	Node*get_buddy(Node*p,size_t s){return(Node*)(((intptr_t)p)^s);} // = address XOR size
	size_t get_metadata_bytes(){return allocated_blocks*metadata_size;}

	Heap() // CONSTRUCTOR
	{
		for (int i = 0; i <= MAX_ORDER + 1; i++) list[i].order = i;
		
		metadata_size		= sizeof(Node);
		// pz: initial stats here or in initializer?
		allocated_blocks	= free_blocks	= 0;
		allocated_bytes		= free_bytes	= 0;

		initialized		= false;
	}

	Return initialize()
	{
		if (initialized) return SUCCESS;

	// Set heap start at multiple of 32*128KB:
		
		void* pointer = sbrk(0);
		if (pointer == BAD_POINTER) return FAILURE;
		
		intptr_t offset	= HEAP_SIZE - ((intptr_t)pointer) % HEAP_SIZE;

		pointer = sbrk(HEAP_SIZE + offset);
		if (pointer == BAD_POINTER) return FAILURE;
		
		
	// Initialize list[10] with 32 free big boy blocks:

		list[MAX_ORDER].head = pointer_addition(pointer, offset);
		
		Node* next;
		Node* previous	= nullptr;
		Node* node		= list[MAX_ORDER].head;

		for (int i = 0; i < BIG_BLOCK_NUM; i++)
		{
			next = i < BIG_BLOCK_NUM - 1 ? pointer_addition(node, BIG_BLOCK_SIZE) : nullptr;
			node->set(MAX_ORDER, 0, true, next, previous);
			
			previous	= node;
			node		= node->next;
		}
		
		// pz: initial stats here or in constructor?
		free_blocks = allocated_blocks  = BIG_BLOCK_NUM;
		free_bytes  = allocated_bytes   = HEAP_SIZE - get_metadata_bytes();

		initialized = true;

		return SUCCESS;
	}

	void* allocate(size_t size)
	{
		int order =  size_to_order(size + metadata_size);

		// MOON map:
		if (order > MAX_ORDER)
		{
			Node* node = Map(size + metadata_size);
			if (node == nullptr) return nullptr;
			node->set(order, size, false, nullptr, nullptr);
			
			allocated_blocks    += 1;
			allocated_bytes     += size;
			
			return get_pointer(node);
		}

		// Find smallest free block:
		int i = order;
		while (i <= MAX_ORDER && list[i].is_empty()) i++;
 
		if (i > MAX_ORDER) return nullptr;

		Node* node = list[i].head;

		list[i].remove(node);
		free_blocks--;

		// Split blocks until desired order is reached:
		while(i > order)
		{
			i--;
			Node* buddy = pointer_addition(node, order_to_size(i));
			list[i].insert(buddy);
			allocated_blocks	+= 1;
			free_blocks			+= 1;
			allocated_bytes		-= metadata_size;
			free_bytes			-= metadata_size;
		}

		node->set(order, size, false, nullptr, nullptr);
		free_bytes -= order_to_size(order) - metadata_size;

		return get_pointer(node);
	}

	Node* merge(Node* node, int order, int max_order, bool is_test)
	{
		Node* buddy = get_buddy(node, order_to_size(order));

		while (order < max_order && buddy->order == order && buddy->is_free)
		{
			if (is_test == false)
			{
				list[order].remove(buddy);
				free_blocks         -= 1;
				allocated_blocks    -= 1;
				free_bytes          += metadata_size;
				allocated_bytes     += metadata_size;
			}
			
			if (pointer_comparison(node, buddy))
				node = buddy;
			
			order++;
			buddy = get_buddy(node, order_to_size(order));
		}

		if (is_test && order != max_order) return nullptr;

		if (!is_test) node->order = order;

		return node;
	}

	void free(void* pointer)
	{
		Node*	node	= get_node(pointer);
		size_t	size	= node->size;
		int		order	= node->order;

		if (node->is_free) return;
		
		// Moon map:
		if (order > MAX_ORDER)
		{
			if (Unmap(node, size) == -1) return;
			allocated_blocks    -= 1;
			allocated_bytes     -= size;
			return;
		}

		free_bytes  += order_to_size(order) - metadata_size;
		free_blocks += 1;
		
		node = merge(node, order, MAX_ORDER, false);

		list[node->order].insert(node);
	}

	void* reallocate(void* old_pointer, size_t new_size)
	{
		Node* old_node = get_node(old_pointer);
		
		int new_order =  size_to_order(new_size);
		int old_order = old_node->order;
		
		// CASE 1: RETURN EXISTING BLOCK:
		if (new_order <= old_order) return old_pointer;

		// CASE 2: MOON MAP
		if (new_order > MAX_ORDER)
		{
			if (new_size == old_node->size) return old_pointer;
			
			void* new_pointer = allocate(new_size);

            std::memmove(new_pointer, old_pointer, new_size); // pz: what size?

			if (new_pointer != nullptr)	free(old_pointer);

			return new_pointer;
		}

		// CASE 3: MERGING SUCCEEDED
		if (merge(old_node, old_order, new_order, true) != nullptr)
		{
			Node* new_node = merge(old_node, old_order, new_order, false);

			new_node->set(new_order, new_size, false, nullptr, nullptr);

			free_bytes -= order_to_size(new_order) - order_to_size(old_order);

			return get_pointer(new_node);
		}

		// CASE 4: NEW ALLOCATION
		void* new_pointer = allocate(new_size);
		if (new_pointer == nullptr) return nullptr;

		std::memmove(new_pointer, old_pointer, order_to_size(old_order)); // pz: what size to use?
		
		free(old_pointer);

		return new_pointer;
	}

	size_t get_free_blocks()		{return free_blocks;		};
	size_t get_free_bytes()			{return free_bytes;			};
	size_t get_allocated_blocks()	{return allocated_blocks;	};
	size_t get_allocated_bytes()	{return allocated_bytes;	};
	size_t get_metadata_size()		{return metadata_size;		};

}; // Heap class

Heap heap;

void* smalloc(size_t size)
{
	if (heap.initialize() == FAILURE || size == 0 || size > MAX_SIZE) return nullptr;
	return heap.allocate(size);
}

void* scalloc(size_t num, size_t size)
{
	size = size * num;

	if (heap.initialize() == FAILURE || size == 0 || size > MAX_SIZE) return nullptr;

	void* pointer = heap.allocate(size);

	if (pointer != nullptr) std::memset(pointer, 0, size);
	
	return pointer;
}

void sfree(void* p) { if (p != nullptr) heap.free(p); }

void* srealloc(void* oldp, size_t size)
{
	if (size == 0 || size > MAX_SIZE) return nullptr;

	if (oldp == nullptr) return heap.allocate(size);

	return heap.reallocate(oldp, size);
}

size_t _num_free_blocks()       { return heap.get_free_blocks();		}
size_t _num_free_bytes()        { return heap.get_free_bytes();		    }
size_t _num_allocated_blocks()  { return heap.get_allocated_blocks();	}
size_t _num_allocated_bytes()   { return heap.get_allocated_bytes();	}
size_t _num_meta_data_bytes()   { return heap.get_metadata_bytes();	    }
size_t _size_meta_data()        { return heap.get_metadata_size();	    }
