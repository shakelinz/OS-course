#include <unistd.h> // sbrk(), size_t

const size_t	MAX_SIZE		= 1E8;
const void*		INVALID_POINTER	= (void*)(-1);

void* smalloc(size_t size)
{
	if (size == 0 || size > MAX_SIZE) return nullptr;

	void* pointer = sbrk(size);

	if (pointer == INVALID_POINTER) return nullptr;

	return pointer;
}