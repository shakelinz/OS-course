#include <unistd.h> // for: sbrk(), size_t
#include <cstring>  // for: memmove(), memset()

const size_t	MAX_SIZE = 1E8;
const void*		INVALID_POINTER = (void*)(-1);

class Heap
{
  private:
	
	struct Node
	{
		size_t	size;
		bool	is_free;
		Node*	next;

		void set(size_t size, bool is_free, Node* next)
		{
			this->size      = size;
			this->is_free   = is_free;
			this->next      = next;
		}
	}; // </Node struct>
  
	Node*	head;
	Node*	tail;
	size_t	free_blocks,	allocated_blocks,
			free_bytes,		allocated_bytes,
			metadata_size;

	Node*Sbrk(intptr_t s){return(Node*)sbrk(s);}
	Node*get_metadata(void*p){return(Node*)p-1;}
	void*get_pointer(Node*p){return(void*)(++p);}

  public:

	Heap() // Constructor:
	{
		free_blocks			= 0;
		free_bytes			= 0;
		allocated_blocks	= 0;
		allocated_bytes		= 0;
		metadata_size		= sizeof(Node);
		
		head = tail = nullptr;
	}

	void* allocate(size_t size)
	{
		Node* node = head;
		
		// Check for free blocks:
		while (node != nullptr)
		{
			if (node->is_free && size <= node->size)
			{
				node->is_free = false;
				free_blocks	-= 1;
				free_bytes	-= node->size;
				return get_pointer(node);
			}
			node = node->next;
		}

		// Create new block:
		node = Sbrk(size + metadata_size);

		if ((void*)node == INVALID_POINTER) return nullptr;
		
		node->set(size, false, nullptr);
		
		if (head == nullptr) head = node; // <- first allocation
		else tail->next = node;
		
		tail = node;

		// Update stats:
		allocated_blocks	+= 1;
		allocated_bytes		+= size;

		return get_pointer(node);
	}

	void free(void* pointer)
	{
		Node* node = get_metadata(pointer);
		node->is_free = true;
		free_blocks	+= 1;
		free_bytes	+= node->size;
	}

	void* reallocate(void* old_pointer, size_t size)
	{
		Node* node = get_metadata(old_pointer);

		if (size <= node->size) return old_pointer;

		void* new_pointer = allocate(size);

		if (new_pointer == nullptr) return nullptr;
		
		std::memmove(new_pointer, old_pointer, size);  // pz: what size?
		
		free(old_pointer);

		return new_pointer;
	}

	size_t get_free_blocks()		{return free_blocks;						}
	size_t get_free_bytes()			{return free_bytes;							}
	size_t get_allocated_blocks()	{return allocated_blocks;					}
	size_t get_allocated_bytes()	{return allocated_bytes;					}
	size_t get_metadata_size()		{return metadata_size;						}
	size_t get_metadata_bytes()		{return allocated_blocks * metadata_size;	}

}; // </Heap class>

Heap heap;

void* smalloc(size_t size)
{
	if (size == 0 || size > MAX_SIZE) return nullptr;
	
	return heap.allocate(size);
}

void* scalloc(size_t num, size_t size)
{
	size = size * num;

	if (size == 0 || size > MAX_SIZE) return nullptr;

	void* pointer = heap.allocate(size);

	if (pointer != nullptr) std::memset(pointer, 0, size);
	
	return pointer;
}

void sfree(void* p) { if (p != nullptr) heap.free(p); }

void* srealloc(void* oldp, size_t size)
{
	if (size == 0 || size > MAX_SIZE) return nullptr;

	if (oldp == nullptr) return heap.allocate(size);
	
	return heap.reallocate(oldp, size);
}

// Statistics getters:
size_t _num_free_blocks()       { return heap.get_free_blocks();      }
size_t _num_free_bytes()        { return heap.get_free_bytes();       }
size_t _num_allocated_blocks()  { return heap.get_allocated_blocks(); }
size_t _num_allocated_bytes()   { return heap.get_allocated_bytes();  }
size_t _num_meta_data_bytes()   { return heap.get_metadata_bytes();   }
size_t _size_meta_data()        { return heap.get_metadata_size();    }